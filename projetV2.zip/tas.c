#include "tas.h"

/* fonction qui créer un tas avec dep comme sommet qui initialise les priotités */
Tas new_tas(int capa_max, int dep)
{
	Tas t;
	t.capacite_max = capa_max;
	t.n=0;
	t.tab = (int*) malloc ( t.capacite_max * sizeof(int) );
	t.priorite = (double*) malloc ( t.capacite_max * sizeof(double) );
	t.pos = (int*) malloc ( t.capacite_max * sizeof(int) );
	t.origine = (int*) malloc (t.capacite_max * sizeof(int) );

	int i;
	t.tab[0] = 0;
	t.pos[0] = -1;
	for( i=1 ; i<t.capacite_max ; i++ )
	{
		t.tab[i] = -1;
		t.pos[i] = -1;
		t.origine[i] = dep;
	}

	return t;
}

/* libère l'espace mémoire d'un tas */
void free_tas(Tas t)
{
	free(t.tab);
	free(t.priorite);
	free(t.pos);
	free(t.origine);
}

/* affiche le tas et ses composantes */
void affiche_tas( Tas t )
{
	printf("\nTas:\nIdentifiant:\t");
	int i;
	for( i=1 ; i<=t.tab[0] ; i++ )
	{
		printf("%d\t",*(t.tab+i));
	}
	printf("\nPriorité:\t");
	for( i=1 ; i<=t.tab[0] ; i++ )
	{
		printf("%3.2f\t",*(t.priorite+i));
	}
	printf("\nOrigine:\t");
	for( i=1 ; i<t.capacite_max ; i++ )
	{
		printf("%d\t",t.origine[i]);
	}
	printf("\nPosition:\t");
	for( i=1 ; i<t.capacite_max ; i++ )
	{
		printf("%d\t",*(t.pos+i));
	}
	printf("\n");
}

/* insert un couple (x,l) d'identifiant x et de priorité l dans le tas T */
void insert(Tas* t, int x, double l, int o)
{
	/*on souhaite insérer un élément en fin de liste donc à la postion du nombre d'élément +1 */
	int new = (t->tab[0])+1;
	if( new >= t->capacite_max ) printf("\n!!!!!!!!!!!!!!!!!!!!!!!!\nPLus de place\n!!!!!!!!!!!!!!!!!!!!!!!!\n");
	else
	{
		/* on ajoute le nouvel élément en fin de liste */
		t->tab[new] = x;
		t->priorite[new] = l;
		//printf("\nindice d'insertion: %d", new);
		t->pos[x] = new;
		t->origine[new] = o;
		
		/* on incrémente le nombre d'élément présent dans le tas */
		t->tab[0]++;
		if( x > t->n ) t->n++;
		
		/* il faut faire remonter l'élément à sa place pour avoir un arbre parfait tournoi */
		while( t->priorite[new] < t->priorite[new/2] && new != 1 )
		{
			/* échange des identifiants */
			int temp = t->tab[new];
			t->tab[new] = t->tab[new/2];
			t->tab[new/2] = temp;
			
			/* échange des origines */
			temp = t->origine[new];
			t->origine[new] = t->origine[new/2];
			t->origine[new/2] = temp;
			
			/* échange des priorités */
			double tempd = t->priorite[new];
			t->priorite[new] = t->priorite[new/2];
			t->priorite[new/2] = tempd;
			
			/* update des positions */
			t->pos[t->tab[new]] = new;
			t->pos[t->tab[new/2]] = new/2;
			
			new = new/2;
		}
		
	}
}

/* retourne l'identifiant de la tache prioritaire */
int tache_prioritaire(Tas t)
{
	return t.tab[1];
}

/* retourne 1 si le tas est vide, 0 sinon */
int est_vide(Tas t)
{
	return t.tab[0] == 0 ;
}

/* retourne 1 si l'élément en position i est une feuille, 0 sinon */
int estFeuille(Tas t,int i)
{
    //printf("\n---\nfonction estFeuille\ntache fils gauche: %d\tposition: %d\n---\n",t.tab[2*i],t.pos[t.tab[2*i]]);
    if( 2*i<t.capacite_max ) return t.pos[t.tab[2*i]] == -1 || t.tab[2*i] == -1;
    else return 2*i > t.tab[0];
}

/* retourne 1 si l'élément à la position i a un fils à droite, 0 sinon */
int aUnFilsD(Tas t, int i)
{
	return !(estFeuille(t,i)) && ((t.pos[t.tab[2*i+1]] != -1) || t.tab[2*i]== -1);
}

/* retourne l'indice de position du fils de gauche de l'élément en position i s'il existe */
int feuilleG(Tas t, int i)
{
	if( !(estFeuille(t,i)) )
	{
		return 2*i;
	}
	else return 0;
}

/* retourne l'indice de position du fils de droite de l'élément en position i s'il existe */
int feuilleD(Tas t, int i)
{
	if( aUnFilsD(t,i) )
	{
		return 2*i+1;
	}
	else return 0;
}

/* retourne l'indice de position du père de l'élément en position i s'il existe */
int pere(Tas t, int i)
{
	if( i > 1 )
	{
		return i/2;
	}
	else return 0;
}

/* supprime du tas l'élément d'identifiant x en supposant qu'il est présent dans le tas */
void supp(Tas* t, int x)
{
	int lg = t->tab[0];
	int ind = t->pos[x];
	//printf("\n--Suppression de l'élément %d\n",t->tab[ind]);
	
	/*on vérifie si l'indice est le dernier élément du tas*/
	if( ind == lg )
	{
		t->tab[0]--;
		t->pos[x] = -1;
		//printf("L'élément a supprimé était le dernier");
		//affiche_tas(*t);
	}
	/*sinon on inverse les positions de l'élément a supprimer et le dernier élément de la liste*/
	else
	{
		/*échange des identifiants*/
		int temp = t->tab[ind];
		t->tab[ind] = t->tab[lg];
		t->tab[lg] = temp;
		
		/*échange des origines*/
		temp = t->origine[ind];
		t->origine[ind] = t->origine[lg];
		t->origine[lg] = temp;
		
		/*échange des priorités*/
		double tempd = t->priorite[ind];
		t->priorite[ind] = t->priorite[lg];
		t->priorite[lg] = tempd;
		
		/*update des positions*/
		t->pos[t->tab[ind]] = ind;
		t->pos[x] = -1;				//-1 signifie que l'élément n'est plus dans le tas
		
		/*on peut réduire la taille du tas*/
		t->tab[0]--;
		//printf("Tas après sa suppression:");
		//affiche_tas(*t);
		
		/*On cherche maintenant a réinserer correctement l'élément mis à l'indice ind
		On cherche à le descendre tant qu'il n'est pas une feuille ou qu'il a des fils de priorité inf */
		
		while( !(estFeuille(*t,ind)) )
		{
			//printf("tab[ind] (%d) n'est pas une feuille\n", t->tab[ind]);
			
			/*On vérifie si l'élément a un fils à droite de prio inf à lui et à son fils de gauche*/
			if( aUnFilsD(*t,ind) && t->priorite[feuilleD(*t,ind)] < t->priorite[ind] && t->priorite[feuilleD(*t,ind)] <= t->priorite[feuilleG(*t,ind)] )
			{
				//printf("tab[ind] (%d) a un fils a droite: %d de priorite: %lf minimum\n", t->tab[ind], t->tab[feuilleD(*t,ind)], t->priorite[feuilleD(*t,ind)]);
				
				/*Dans ce cas on inverse les positions avec le fils de droite
				échange des identifiants */
				int temp = t->tab[ind];
				t->tab[ind] = t->tab[feuilleD(*t,ind)];
				t->tab[feuilleD(*t,ind)] = temp;
				
				/*échange des origines*/
				temp = t->origine[ind];
				t->origine[ind] = t->origine[feuilleD(*t,ind)];
				t->origine[feuilleD(*t,ind)] = temp;
				
				/*échange des priorités*/
				double tempd = t->priorite[ind];
				t->priorite[ind] = t->priorite[feuilleD(*t,ind)];
				t->priorite[feuilleD(*t,ind)] = tempd;
				
				/*update des positions*/
				t->pos[t->tab[ind]] = ind;
				t->pos[t->tab[feuilleD(*t,ind)]] = feuilleD(*t,ind);
				
				//printf("Inversion done!");
				//affiche_tas(*t);

				/*maj de l'indice pour le tour suivant -> ind prend l'indice du fils a droite*/
				ind = feuilleD(*t,ind);
				
				//printf("nouveau ind: %d\ttache: %d\n", ind, t->tab[ind]);
			}
			
			/*sinon on vérifie si le fils à gauche est de prio inf*/
			else if( t->priorite[feuilleG(*t,ind)] < t->priorite[ind] )
			{
				//printf("tab[ind] (%d) a un fils a gauche: %d de priorite: %lf\n", t->tab[ind], t->tab[feuilleG(*t,ind)], t->priorite[feuilleG(*t,ind)]);
				
				/*Dans ce cas on inverse les positions avec le fils de gauche
				échange des identifiants*/
				int temp = t->tab[ind];
				t->tab[ind] = t->tab[feuilleG(*t,ind)];
				t->tab[feuilleG(*t,ind)] = temp;
				
				/*échange des origines*/
				temp = t->origine[ind];
				t->origine[ind] = t->origine[feuilleG(*t,ind)];
				t->origine[feuilleG(*t,ind)] = temp;
				
				/*échange des priorités*/
				double tempd = t->priorite[ind];
				t->priorite[ind] = t->priorite[feuilleG(*t,ind)];
				t->priorite[feuilleG(*t,ind)] = tempd;
				
				/*update des positions*/
				t->pos[t->tab[ind]] = ind;
				t->pos[t->tab[feuilleG(*t,ind)]] = feuilleG(*t,ind);
				
				//printf("Inversion done!");
				//affiche_tas(*t);

				/*maj de l'indice pour le tour suivant -> ind prend l'indice du fils a droite*/
				ind = feuilleG(*t,ind);
				
				//printf("nouveau ind: %d\ttache: %d\n", ind, t->tab[ind]);
			}
			
			//Si ancune des conditions précédentes ne sont remplies alors on sort du while
			else
			{
			    //printf("pas de fils de priorite inf\n");
                break;
            }
		}
		
		//On va faire remonter l'élément le plus haut possible avec ses pères d'indice ind/2
		while( t->priorite[ind] < t->priorite[ind/2] && ind != 1 )
		{
			//échange des identifiants
			int temp = t->tab[ind];
			t->tab[ind] = t->tab[ind/2];
			t->tab[ind/2] = temp;
			
			//échange des origines
			temp = t->origine[ind];
			t->origine[ind] = t->origine[ind/2];
			t->origine[ind/2] = temp;
			
			//échange des priorités
			double tempd = t->priorite[ind];
			t->priorite[ind] = t->priorite[ind/2];
			t->priorite[ind/2] = tempd;
			
			//update des positions
			t->pos[t->tab[ind]] = ind;
			t->pos[t->tab[ind/2]] = ind/2;
			
			//maj de l'indice pour le tour suivant -> il prend l'indice du père
			ind = ind/2;
		}
		//printf("tab[ind] (%d) est une feuille ou est bien positionné\n",t->tab[ind]);
	}
}

/* supprime l'élément ( x, l) de valeur l minimum dans K et qui retourne le sommet x */
int recup_min(Tas *t)
{
	//printf("\ntache prioritaire: %d\tpriorite: %3.2f\n",tache_prioritaire(*t),t->priorite[1]);
	supp(t,t->tab[1]);
	return tache_prioritaire(*t);
}






//--------------------------------------MAIN-----------------------------------------------

/*int main()
{
	//initialisation d'un tableau
	Tas t = new_tas(C);
	insert(&t,1,12);
	//affiche_tas(t);
	insert(&t,2,5);
	//affiche_tas(t);
	insert(&t,3,6);
	//affiche_tas(t);
	insert(&t,4,7);
	//affiche_tas(t);
	insert(&t,5,14);
	//affiche_tas(t);
	insert(&t,6,4);

	affiche_tas(t);
	printf("\ntache prioritaire: %d\tpriorite: %3.2f\n",tache_prioritaire(t),*(t.priorite+1));

	supp(&t,6);

	printf("\ninsertion de (7,2)");
	insert(&t,7,2);
	affiche_tas(t);

	recup_min(&t);
	affiche_tas(t);
	printf("\ntache prio: %d\n",tache_prioritaire(t));

	printf("Suppression de l'élément 5");
	supp(&t,5);
	affiche_tas(t);


	free_tas(t);
	return 0;
}*/
