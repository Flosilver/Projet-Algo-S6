#ifndef TAS_H
#define TAS_H

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#define C 100

typedef struct tas
{
	int capacite_max;		//nombre maximum d'éléments dans le tas
	int n; 					//nombre d'élément dans le tas
	int *tab;				//tableau des éléments du tas (de tab[1] à tab[n])
	double *priorite;			//tableau des cles des éléments du tas
	int *pos; 				//tableau des positions des éléments du tas
	int *origine;           //tableau des sommets d'origine qui sont associés à la priorité
}Tas;

/* fonction qui créer un tas avec dep comme sommet qui initialise les priotités */
Tas new_tas(int capa_max, int dep);

/* libère l'espace mémoire d'un tas */
void free_tas(Tas t);

/* affiche le tas et ses composantes */
void affiche_tas( Tas t );

/* insert un couple (x,l) d'identifiant x et de priorité l dans le tas T */
void insert(Tas *T, int x, double l, int o);

/* retourne l'identifiant de la tache prioritaire */
int tache_prioritaire(Tas t);

/* retourne 1 si le tas est vide, 0 sinon */
int est_vide(Tas t);

/* retourne 1 si l'élément en position i est une feuille, 0 sinon */
int estFeuille(Tas t,int i);

/* retourne 1 si l'élément à la position i a un fils à droite, 0 sinon */
int aUnFilsD(Tas t, int i);

/* retourne l'indice de position du fils de gauche de l'élément en position i s'il existe */
int feuilleG(Tas t, int i);

/* retourne l'indice de position du fils de droite de l'élément en position i s'il existe */
int feuilleD(Tas t, int i);

/* retourne l'indice de position du père de l'élément en position i s'il existe */
int pere(Tas t, int i);

/* supprime du tas l'élément d'identifiant x en supposant qu'il est présent dans le tas */
void supp(Tas* T, int x);

/* supprime l'élément ( x, l) de valeur l minimum dans K et qui retourne le sommet x */
int recup_min(Tas *t);

#endif
